#include "pcf8574.h"

HAL_StatusTypeDef PCF8574_Write(I2C_HandleTypeDef *hi2c, uint8_t data)
{
    return HAL_I2C_Master_Transmit(hi2c, PCF8574_ADDR, &data, 1, 100);
}

HAL_StatusTypeDef PCF8574_Read(I2C_HandleTypeDef *hi2c, uint8_t *data)
{
    return HAL_I2C_Master_Receive(hi2c, PCF8574_ADDR, data, 1, 100);
}
