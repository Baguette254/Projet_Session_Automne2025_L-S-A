#ifndef MODE_AUTO_H
#define MODE_AUTO_H

#include <stdint.h>

typedef enum
{
    AUTO_IDLE = 0,
    AUTO_GO_TO_BLOCK,
    AUTO_DESCEND,
    AUTO_GRAB,
    AUTO_LIFT,
    AUTO_GO_TO_SCALE,
    AUTO_DROP_ON_SCALE,
    AUTO_WAIT_STABLE,
    AUTO_READ_WEIGHT,
    AUTO_GO_TO_INTERMEDIATE,
    AUTO_GO_TO_BIN,
    AUTO_RELEASE,
    AUTO_RETURN_HOME,
    AUTO_DONE
} AutoState_t;

void Auto_Init(void);
uint8_t Auto_IsRunning(void);
void Auto_Start(uint8_t zone);
void Auto_Update(void);
void Auto_Display(const char *stepName);

#endif
