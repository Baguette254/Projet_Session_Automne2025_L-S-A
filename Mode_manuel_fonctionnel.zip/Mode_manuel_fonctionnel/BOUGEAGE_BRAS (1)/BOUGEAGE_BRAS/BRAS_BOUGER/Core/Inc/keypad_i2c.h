#ifndef KEYPAD_I2C_H
#define KEYPAD_I2C_H

#include "stm32f1xx_hal.h"
#include "pcf8574.h"

// Prototype
char Keypad_I2C_GetKey(I2C_HandleTypeDef *hi2c);

#endif
