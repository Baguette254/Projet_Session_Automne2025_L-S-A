#ifndef MODE_MANUEL_H
#define MODE_MANUEL_H

#include "stm32f1xx_hal.h"

// variables globales définies dans main.c :
extern uint8_t motors[5];
extern uint8_t selectedMotor;
extern uint8_t step;
extern UART_HandleTypeDef huart1;

// prototype
void Mode_Manuel_HandleKey(char key);

#endif
