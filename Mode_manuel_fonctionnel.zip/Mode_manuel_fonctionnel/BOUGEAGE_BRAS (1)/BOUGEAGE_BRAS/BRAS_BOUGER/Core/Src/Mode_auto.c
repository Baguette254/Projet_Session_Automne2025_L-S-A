#include "Mode_auto.h"
#include "main.h"
#include "UART.h"
#include "lcd.h"
#include "lecture_adc.h"
#include "Mode_Manuel.h"
#include <string.h>
#include <stdio.h>


extern UART_HandleTypeDef huart1;
extern uint8_t motors[5];
extern UART_Data_t UART_ParsedData;

AutoState_t autoState = AUTO_IDLE;
uint8_t autoZone = 0;
uint8_t autoStep = 0;

/* ============================================================
 * INIT
 * ============================================================*/
void Auto_Init(void)
{
    autoState = AUTO_IDLE;
    autoZone = 0;
    autoStep = 0;
}

/* ============================================================
 * TEST SI MODE AUTO EST EN COURS
 * ============================================================*/
uint8_t Auto_IsRunning(void)
{
    return (autoState != AUTO_IDLE && autoState != AUTO_DONE);
}

/* ============================================================
 * LANCEMENT DU MODE AUTO
 * ============================================================*/
void Auto_Start(uint8_t zone)
{
    if (Auto_IsRunning()) return;

    autoZone = zone; // 1=A, 2=B, 3=C
    autoStep = 1;
    autoState = AUTO_GO_TO_BLOCK;

    LCD_Clear();
    LCD_Print("AUTO START ZONE ");
    LCD_PutChar('0' + zone);
    HAL_Delay(400);
}

/* ============================================================
 * POSITIONS DE BASE
 * ============================================================*/
static void MoveToBlock(uint8_t zone)
{
    switch(zone)
    {
        case 1: motors[0]=139; motors[1]=90; motors[2]=20; motors[3]=130; break;
        case 2: motors[0]=144; motors[1]=99; motors[2]=30; motors[3]=123; break;
        case 3: motors[0]=147; motors[1]=109; motors[2]=46; motors[3]=128; break;
    }
}

static void MoveToScale(void)
{
    motors[0]=138;
    motors[1]=124;
    motors[2]=78;
    motors[3]=145;
}

static void MoveToIntermediate(void)
{
    motors[0]=156;
    motors[1]=103;
    motors[2]=53;
    motors[3]=140;
}

static void MoveToBin(uint8_t bin)
{
    switch(bin)
    {
        case 1: motors[0]=160;  motors[1]=102; motors[2]=36; motors[3]=11 ; break;
        case 2: motors[0]=157;  motors[1]=110; motors[2]=51; motors[3]=133; break;
        case 3: motors[0]=155;  motors[1]=113; motors[2]=57; motors[3]=135; break;
    }
}
/* ============================================================
 * AFFICHAGE AUTOMATIQUE (AJOUTE ICI)
 * ============================================================*/
void Auto_Display(const char *stepName)
{
    char line[17];

    /* --- AFFICHAGE MODE AUTO EN LIGNES 0 ET 1 --- */
    if (Auto_IsRunning())
    {
        LCD_SetCursor(0,0);
        sprintf(line, "AUTO Z:%c", 'A' + autoZone - 1);
        LCD_Print(line);

        LCD_SetCursor(0,1);
        LCD_Print(stepName);
    }

    /* --- LIGNE 2 : X et Y TOUJOURS --- */
    LCD_SetCursor(0,2);
    sprintf(line, "X:%3d Y:%3d",
            UART_ParsedData.ucX, UART_ParsedData.ucY);
    LCD_Print(line);

    /* --- LIGNE 3 : ADC TOUJOURS --- */
    LCD_SetCursor(0,3);
    sprintf(line, "ADC:%4s", ADC_Read_Seuils());
    LCD_Print(line);
}

/* ============================================================
 * MACHINE D'ÉTAT AUTOMATIQUE
 * ============================================================*/
void Auto_Update(void)
{
    switch(autoState)
    {
        case AUTO_IDLE:
            return;

        /* Aller chercher bloc */
        case AUTO_GO_TO_BLOCK:
            Auto_Display("GO_BLOCK");
            MoveToBlock(autoZone);
            UART_SendMotors(&huart1, motors);
            autoState = AUTO_DESCEND;
            HAL_Delay(1500);
            break;

        case AUTO_DESCEND:
            Auto_Display("DESCEND");
            motors[1] += 1;
            UART_SendMotors(&huart1, motors);
            autoState = AUTO_GRAB;
            HAL_Delay(1000);
            break;

        case AUTO_GRAB:
            Auto_Display("GRAB");
            motors[4] = 205;
            motors[3] -= 3;

            UART_SendMotors(&huart1, motors);
            autoState = AUTO_LIFT;
            HAL_Delay(600);
            break;

        case AUTO_LIFT:
            Auto_Display("LIFT");
            motors[1] -= 30;
            UART_SendMotors(&huart1, motors);
            autoState = AUTO_GO_TO_SCALE;
            HAL_Delay(1000);
            break;

        /* Aller déposer sur balance */
        case AUTO_GO_TO_SCALE:
            Auto_Display("TO_SCALE");
             motors[0]=139; motors[1]=100; motors[2]=67; motors[3]=138;
            UART_SendMotors(&huart1, motors);

            HAL_Delay(1500);


            MoveToScale();
            UART_SendMotors(&huart1, motors);
            HAL_Delay(2000);
            autoState = AUTO_DROP_ON_SCALE;
            HAL_Delay(1000);
            break;

        /* Déposer bloc et lever */
        case AUTO_DROP_ON_SCALE:
            Auto_Display("DROP");
            motors[1] = 126;
            motors[4] = 0; // ouvrir pince
            UART_SendMotors(&huart1, motors);
            HAL_Delay(1000);

            motors[1] -= 10; // lever un peu
            UART_SendMotors(&huart1, motors);

            autoState = AUTO_WAIT_STABLE;
            break;

        /* Attente stabilisation balance */
        case AUTO_WAIT_STABLE:
            Auto_Display("WAIT");
            HAL_Delay(3000);
            autoState = AUTO_READ_WEIGHT;
            break;

        /* Lire l’ADC */
        case AUTO_READ_WEIGHT:
        {
            Auto_Display("READ");
            const char *txt = ADC_Read_Seuils();

            if (strcmp(txt, "<1V") == 0)
                autoZone = 1;
            else if (strcmp(txt, "1-2V") == 0)
                autoZone = 2;
            else
                autoZone = 3;

            /* Avant de repartir → redescendre pince */
            motors[1] += 6;  // redescendre même hauteur
            UART_SendMotors(&huart1, motors);
            HAL_Delay(1000);
            motors[4]=205;    //ramasser
            HAL_Delay(1000);
            motors[1] -= 20; // lever un peu

            UART_SendMotors(&huart1, motors);

            autoState = AUTO_GO_TO_INTERMEDIATE;
            HAL_Delay(2000);
            break;
        }

        /* Aller à la position intermédiaire */
        case AUTO_GO_TO_INTERMEDIATE:
            Auto_Display("INTER");
            MoveToIntermediate();
            UART_SendMotors(&huart1, motors);
            autoState = AUTO_GO_TO_BIN;
            HAL_Delay(5000);
            break;

        /* Aller déposer dans le bac selon poids */
        case AUTO_GO_TO_BIN:
            Auto_Display("TO_BIN");
            MoveToBin(autoZone);
            UART_SendMotors(&huart1, motors);
            autoState = AUTO_RELEASE;
            HAL_Delay(5000);
            break;

        case AUTO_RELEASE:
            Auto_Display("RELEASE");
            motors[4] = 0;
            UART_SendMotors(&huart1, motors);
            autoState = AUTO_RETURN_HOME;
            HAL_Delay(4000);
            break;

        case AUTO_RETURN_HOME:
            Auto_Display("HOME");
            motors[0]=139; motors[1]=76; motors[2]=20; motors[3]=138; motors[4]=0;
            UART_SendMotors(&huart1, motors);

            autoState = AUTO_DONE;
            HAL_Delay(5000);
            break;

        case AUTO_DONE:
            LCD_Clear();
            LCD_Print("AUTO DONE");
            HAL_Delay(5000);
            Auto_Init();
            break;
    }
}
