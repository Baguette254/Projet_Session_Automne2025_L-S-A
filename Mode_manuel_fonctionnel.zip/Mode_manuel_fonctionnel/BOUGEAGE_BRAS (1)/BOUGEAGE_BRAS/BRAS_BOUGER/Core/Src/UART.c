#include "UART.h"
#include "main.h"

uint8_t UART_RxByte = 0;
uint8_t UART_LastBytes[8];
uint8_t idx = 0;
uint8_t UART_NewFrame = 0;

UART_Data_t UART_ParsedData;

void UART_Init_IT(UART_HandleTypeDef *huart)
{
    HAL_UART_Receive_IT(huart, &UART_RxByte, 1);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    UART_LastBytes[idx++] = UART_RxByte;

    if (idx >= 8)
    {
        idx = 0;
        UART_NewFrame = 1;
    }

    HAL_UART_Receive_IT(huart, &UART_RxByte, 1);
}
void UART_ProcessFrame(void)
{
    if (!UART_NewFrame) return;
    UART_NewFrame = 0;

    // Vérif header
    if (UART_LastBytes[0] != 'G' || UART_LastBytes[1] != 'O')
        return;

    // Vérif checksum
    uint8_t sum = 0;
    for (int i = 0; i < 7; i++)
        sum += UART_LastBytes[i];

    if (sum != UART_LastBytes[7])
        return;

    // Décode dans la structure propre
    UART_ParsedData.ucX       = UART_LastBytes[2];
    UART_ParsedData.ucY       = UART_LastBytes[3];
    UART_ParsedData.ucPince   = UART_LastBytes[4];
    UART_ParsedData.ucBalance = UART_LastBytes[5];
    UART_ParsedData.ucReserve = UART_LastBytes[6];
}
void UART_SendMotors(UART_HandleTypeDef *huart, uint8_t *motors)
{
    uint8_t trame[8];
    uint8_t checksum = 0;

    trame[0] = 'G';
    trame[1] = 'O';
    trame[2] = motors[0];
    trame[3] = motors[1];
    trame[4] = motors[2];
    trame[5] = motors[3];
    trame[6] = motors[4];

    for (int i = 0; i < 7; i++)
        checksum += trame[i];

    trame[7] = checksum;

    HAL_UART_Transmit(huart, trame, 8, 50);
}
