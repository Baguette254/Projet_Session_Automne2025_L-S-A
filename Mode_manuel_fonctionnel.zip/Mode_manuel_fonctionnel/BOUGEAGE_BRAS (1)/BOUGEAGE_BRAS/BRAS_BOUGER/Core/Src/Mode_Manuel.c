#include "Mode_Manuel.h"
#include "UART.h"
#include "lcd.h"
#include <stdio.h>

void Mode_Manuel_HandleKey(char key)
{
    switch(key)
    {
        case '1': selectedMotor = 0; break;
        case '2': selectedMotor = 1; break;
        case '3': selectedMotor = 2; break;
        case '4': selectedMotor = 3; break;
        case '5': selectedMotor = 4; break;

        case '0':
            step++;
            if (step > 16) step = 1;
            break;

        case '*':   // descendre
            if (motors[selectedMotor] >= step)
                motors[selectedMotor] -= step;
            else
                motors[selectedMotor] = 0;
            break;

        case '#':   // monter
            if (motors[selectedMotor] + step <= 205)
                motors[selectedMotor] += step;
            else
                motors[selectedMotor] = 205;
            break;

        case 'A':
            // séquence spéciale plus tard
            break;

        default:
            return; // touche inutile
    }

    // Mettre à jour le PIC
    UART_SendMotors(&huart1, motors);

    // Mettre à jour l'afficheur
    LCD_Clear();

    char buf[17];

    // Ligne 0 : moteur sélectionné + valeur
    snprintf(buf, 17, "M%d Val:%3d", selectedMotor, motors[selectedMotor]);
    LCD_SetCursor(0,0);
    LCD_Print(buf);

    // Ligne 1 : step actuel
    snprintf(buf, 17, "Step:%2d", step);
    LCD_SetCursor(0,1);
    LCD_Print(buf);
}
