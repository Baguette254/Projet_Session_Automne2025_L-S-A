#include "main.h"
#include "stm32f1xx_hal.h"
#include "lcd.h"
#include "keypad.h"

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
void Error_Handler(void);

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();   // prépare le port B pour le LCD
    Keypad_Init();    // prépare le port A pour le clavier

    LCD_Init();
    LCD_Clear();


    // Message d'accueil
    LCD_SetCursor(0,0);
    LCD_Print("Keypad -> LCD");
    LCD_SetCursor(0,1);
    LCD_Print("Tape une touche:");

    // On écrira les touches à partir de ligne 3 (row=2)
    uint8_t cursor_col = 0;
    uint8_t cursor_row = 2;

    while (1)
    {
        char key = Keypad_GetKey();

        if (key != 0)
        {

            LCD_SetCursor(cursor_col, cursor_row);
            LCD_PutChar((uint8_t)key);


            // avance le curseur
            cursor_col++;
            if (cursor_col >= 20) {
                cursor_col = 0;
                cursor_row++;
                if (cursor_row >= 4) {
                    cursor_row = 2; // reboucle sur ligne 3
                }
            }

            // anti-repeat : évite de spammer la même touche en continu
            HAL_Delay(200);
        }

        HAL_Delay(20); // polling régulier
    }
}

/* Horloge système (garde la version générée par Cube si différente) */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource       = RCC_PLLSOURCE_HSI_DIV2;
    RCC_OscInitStruct.PLL.PLLMUL          = RCC_PLL_MUL16;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK   |
                                       RCC_CLOCKTYPE_SYSCLK |
                                       RCC_CLOCKTYPE_PCLK1  |
                                       RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2);
}

/*
 * MX_GPIO_Init()
 * --------------
 * configure le PORT B pour le LCD :
 * PB9..PB15 en sortie push-pull
 *
 * NOTE : on NE TOUCHE PAS ici à GPIOA,
 * parce que Keypad_Init() le fait déjà.
 */
static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOB_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // mettre PB9..PB15 à 0
    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_9  | GPIO_PIN_10 | GPIO_PIN_11 |
                      GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15,
                      GPIO_PIN_RESET);

    // config PB9..PB15 en sortie push-pull
    GPIO_InitStruct.Pin   = GPIO_PIN_9  | GPIO_PIN_10 | GPIO_PIN_11 |
                            GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        // boucle bloquante en cas d'erreur
    }
}
