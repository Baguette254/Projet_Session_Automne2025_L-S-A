#include "keypad.h"

/*
 * Table de correspondance [row][col]
 *
 *  row0: 1  2  3  A
 *  row1: 4  5  6  B
 *  row2: 7  8  9  C
 *  row3: *  0  #  D
 */
static const char keymap[4][4] = {
    { '1', '2', '3', 'A' },
    { '4', '5', '6', 'B' },
    { '7', '8', '9', 'C' },
    { '*', '0', '#', 'D' }
};

/* Prototypes internes */
static void Keypad_SetAllColsHigh(void);
static void Keypad_DriveColLow(uint8_t colIndex);
static uint8_t Keypad_ReadRows(void);

/*
 * Keypad_Init()
 * -------------
 * Configure :
 *  - Colonnes (PA5..PA8) en sortie push-pull (repos = HIGH)
 *  - Lignes   (PA1..PA4) en entrée pull-up
 */
void Keypad_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Colonnes -> sorties push-pull
    GPIO_InitStruct.Pin = KEYPAD_COL0_PIN | KEYPAD_COL1_PIN |
                          KEYPAD_COL2_PIN | KEYPAD_COL3_PIN;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(KEYPAD_COL_GPIO, &GPIO_InitStruct);

    // Lignes -> entrées avec pull-up
    GPIO_InitStruct.Pin = KEYPAD_ROW0_PIN | KEYPAD_ROW1_PIN |
                          KEYPAD_ROW2_PIN | KEYPAD_ROW3_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(KEYPAD_ROW_GPIO, &GPIO_InitStruct);

    // Repos: toutes les colonnes HIGH
    Keypad_SetAllColsHigh();
}

/*
 * Keypad_SetAllColsHigh()
 * -----------------------
 * Met les 4 colonnes PA5..PA8 à l'état HIGH.
 * (Aucune n'est tirée à 0.)
 */
static void Keypad_SetAllColsHigh(void)
{
    HAL_GPIO_WritePin(KEYPAD_COL_GPIO,
                      KEYPAD_COL0_PIN | KEYPAD_COL1_PIN |
                      KEYPAD_COL2_PIN | KEYPAD_COL3_PIN,
                      GPIO_PIN_SET);
}

/*
 * Keypad_DriveColLow(colIndex)
 * ----------------------------
 * colIndex = 0..3
 * On met seulement CETTE colonne à LOW,
 * les autres restent HIGH.
 */
static void Keypad_DriveColLow(uint8_t colIndex)
{
    // D'abord, toutes HIGH
    Keypad_SetAllColsHigh();

    switch (colIndex)
    {
        case 0:
            HAL_GPIO_WritePin(KEYPAD_COL_GPIO, KEYPAD_COL0_PIN, GPIO_PIN_RESET); // LOW
            break;
        case 1:
            HAL_GPIO_WritePin(KEYPAD_COL_GPIO, KEYPAD_COL1_PIN, GPIO_PIN_RESET);
            break;
        case 2:
            HAL_GPIO_WritePin(KEYPAD_COL_GPIO, KEYPAD_COL2_PIN, GPIO_PIN_RESET);
            break;
        case 3:
            HAL_GPIO_WritePin(KEYPAD_COL_GPIO, KEYPAD_COL3_PIN, GPIO_PIN_RESET);
            break;
        default:
            break;
    }
}

/*
 * Keypad_ReadRows()
 * -----------------
 * Lit les 4 lignes (PA1..PA4).
 *
 * Chaque bit du résultat correspond à une ligne :
 *   bit0 => ROW0 (PA1)
 *   bit1 => ROW1 (PA2)
 *   bit2 => ROW2 (PA3)
 *   bit3 => ROW3 (PA4)
 *
 * Rappel :
 * - Les lignes ont des pull-up internes -> normalement HIGH.
 * - Si une touche relie la colonne LOW à la ligne, la ligne devient LOW.
 *   => donc on détecte "appuyé" quand c'est LOW.
 *
 * On renvoie un masque 4 bits avec '1' là où c'est appuyé.
 */
static uint8_t Keypad_ReadRows(void)
{
    uint8_t mask = 0;

    if (HAL_GPIO_ReadPin(KEYPAD_ROW_GPIO, KEYPAD_ROW0_PIN) == GPIO_PIN_RESET) mask |= (1 << 0);
    if (HAL_GPIO_ReadPin(KEYPAD_ROW_GPIO, KEYPAD_ROW1_PIN) == GPIO_PIN_RESET) mask |= (1 << 1);
    if (HAL_GPIO_ReadPin(KEYPAD_ROW_GPIO, KEYPAD_ROW2_PIN) == GPIO_PIN_RESET) mask |= (1 << 2);
    if (HAL_GPIO_ReadPin(KEYPAD_ROW_GPIO, KEYPAD_ROW3_PIN) == GPIO_PIN_RESET) mask |= (1 << 3);

    return mask;
}

/*
 * Keypad_GetKey()
 * ---------------
 * Balaye les 4 colonnes (PA5..PA8).
 * Pour chaque colonne :
 *   - On force cette colonne LOW.
 *   - On lit les 4 lignes (PA1..PA4).
 *   - Si une ligne devient LOW -> touche détectée.
 *
 * Debounce logiciel simple (20ms).
 *
 * Retour :
 *   - caractère correspondant ('1','2','3','A', etc.)
 *   - 0 si aucune touche
 */
char Keypad_GetKey(void)
{
    for (uint8_t col = 0; col < 4; col++)
    {
        // Activer cette colonne
        Keypad_DriveColLow(col);

        HAL_Delay(1); // petit temps de stabilisation des contacts

        // Lire les lignes
        uint8_t rowsMask = Keypad_ReadRows();

        if (rowsMask != 0)
        {
            // debounce : re-vérifier après 20ms
            HAL_Delay(20);
            if (Keypad_ReadRows() == rowsMask)
            {
                // Trouver quelle ligne est active
                for (uint8_t row = 0; row < 4; row++)
                {
                    if (rowsMask & (1 << row))
                    {
                        // Remettre toutes les colonnes HIGH avant de quitter
                        Keypad_SetAllColsHigh();

                        // Retourner la bonne touche depuis la table
                        return keymap[row][col];
                    }
                }
            }
        }
    }

    // Aucune touche
    Keypad_SetAllColsHigh();
    return 0;
}
