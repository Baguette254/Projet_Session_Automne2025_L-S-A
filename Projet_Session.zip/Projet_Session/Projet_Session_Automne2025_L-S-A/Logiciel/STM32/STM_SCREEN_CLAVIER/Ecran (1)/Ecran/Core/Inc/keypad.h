#ifndef KEYPAD_H
#define KEYPAD_H

#include "stm32f1xx_hal.h"
#include <stdint.h>

/*
 * CLAVIER 4x4 - câblage RÉEL donné par toi :
 *
 * LIGNES (inputs avec pull-up) :
 *   ROW0 -> PA1
 *   ROW1 -> PA2
 *   ROW2 -> PA3
 *   ROW3 -> PA4
 *
 * COLONNES (outputs qu'on force LOW une à une) :
 *   COL0 -> PA5
 *   COL1 -> PA6
 *   COL2 -> PA7
 *   COL3 -> PA8
 *
 * Rappel disposition physique du clavier :
 *
 *   Row0: [1] [2] [3] [A]
 *   Row1: [4] [5] [6] [B]
 *   Row2: [7] [8] [9] [C]
 *   Row3: [*] [0] [#] [D]
 */

#define KEYPAD_ROW_GPIO      GPIOA
#define KEYPAD_ROW0_PIN      GPIO_PIN_1
#define KEYPAD_ROW1_PIN      GPIO_PIN_2
#define KEYPAD_ROW2_PIN      GPIO_PIN_3
#define KEYPAD_ROW3_PIN      GPIO_PIN_4

#define KEYPAD_COL_GPIO      GPIOA
#define KEYPAD_COL0_PIN      GPIO_PIN_5
#define KEYPAD_COL1_PIN      GPIO_PIN_6
#define KEYPAD_COL2_PIN      GPIO_PIN_7
#define KEYPAD_COL3_PIN      GPIO_PIN_8

/* Initialise les GPIOs du clavier */
void Keypad_Init(void);

/* Lit une touche :
 *  - retourne '1','2','3','A','4','5', ... '*','0','#','D'
 *  - retourne 0 si aucune touche n'est pressée
 */
char Keypad_GetKey(void);

#endif // KEYPAD_H
