/*
 * TestClavier.h
 *
 *  Created on: Nov 26, 2025
 *      Author: 2001082
 */

#ifndef INC_TESTCLAVIER_H_
#define INC_TESTCLAVIER_H_

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Fonction principale de test du clavier.
 * À appeler en boucle depuis main().
 */
void TestClavier_Task(void);

#ifdef __cplusplus
}
#endif





#endif /* INC_TESTCLAVIER_H_ */
