#ifndef PCF8574_H
#define PCF8574_H

#include "stm32f1xx_hal.h"

// Adresse 7 bits du PCF8574N, A0=A1=A2=GND => 0x20
#define PCF8574_ADDR     (0x20 << 1)

HAL_StatusTypeDef PCF8574_Write(I2C_HandleTypeDef *hi2c, uint8_t data);
HAL_StatusTypeDef PCF8574_Read(I2C_HandleTypeDef *hi2c, uint8_t *data);

#endif
