#ifndef __UART_H
#define __UART_H

#include "stm32f1xx_hal.h"

/* Structure de données reçues */
typedef struct {
    uint8_t ucX;
    uint8_t ucY;
    uint8_t ucPince;
    uint8_t ucBalance;
    uint8_t ucReserve;
} UART_Data_t;

/* Variables externes partagées */
extern uint8_t UART_RxByte;
extern uint8_t UART_LastBytes[8];
extern uint8_t UART_NewFrame;
extern UART_Data_t UART_ParsedData;

/* Fonctions */
void UART_Init_IT(UART_HandleTypeDef *huart);
void UART_ProcessFrame(void);
void UART_SendMotors(UART_HandleTypeDef *huart, uint8_t *motors);

#endif
