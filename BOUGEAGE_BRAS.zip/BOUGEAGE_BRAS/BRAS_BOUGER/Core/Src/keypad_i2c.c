#include "keypad_i2c.h"

// Table de correspondance des touches 4x4
static const char keypad_map[4][4] =
{
    {'1','2','3','A'},
    {'4','5','6','B'},
    {'7','8','9','C'},
    {'*','0','#','D'}
};

// ----------------------------------------------------------------------
// Fonction : Keypad_I2C_GetKey()
// Renvoie : caractère de la touche pressée ou 0 si aucune touche
// ----------------------------------------------------------------------
char Keypad_I2C_GetKey(I2C_HandleTypeDef *hi2c)
{
    uint8_t read_val;

    for (int col = 0; col < 4; col++)
    {
        uint8_t out = 0xFF;

        // Mettre UNE colonne à LOW (P4–P7)
        out &= ~(1 << (4 + col));

        // Écrire la colonne active
        if (PCF8574_Write(hi2c, out) != HAL_OK)
            return 0; // I2C error

        HAL_Delay(2);

        // Lire les lignes (P0–P3)
        if (PCF8574_Read(hi2c, &read_val) != HAL_OK)
            return 0;

        uint8_t row_val = read_val & 0x0F;

        // Une touche pressée tire la ligne à LOW
        for (int row = 0; row < 4; row++)
        {
            if ((row_val & (1 << row)) == 0)
            {
                // Anti-rebond simple
                HAL_Delay(30);
                return keypad_map[row][col];
            }
        }
    }

    return 0; // aucune touche
}
