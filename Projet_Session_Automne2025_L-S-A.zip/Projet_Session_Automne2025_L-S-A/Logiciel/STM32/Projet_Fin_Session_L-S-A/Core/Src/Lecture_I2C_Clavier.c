#include "Lecture_I2C_Clavier.h"

/* Handle I2C interne */
static I2C_HandleTypeDef *s_hi2c = NULL;


/* =====================================================================
   Initialise le module Clavier I2C
   ===================================================================== */
void ClavierI2C_Init(I2C_HandleTypeDef *hi2c)
{
    s_hi2c = hi2c;
}


/* =====================================================================
   Vérifie si le clavier I2C (adresse 0x28) répond.
   Retourne :
     - HAL_OK si ACK reçu
     - HAL_ERROR / HAL_TIMEOUT sinon
   ===================================================================== */
HAL_StatusTypeDef ClavierI2C_IsReady(void)
{
    if (s_hi2c == NULL)
    {
        return HAL_ERROR;
    }

    return HAL_I2C_IsDeviceReady(s_hi2c,
                                 CLAVIER_I2C_ADDR,
                                 3,     // 3 tentatives
                                 10);   // timeout 10 ms
}


/* =====================================================================
   Lit un octet depuis le clavier.
   Retourne HAL_OK si lecture réussie.
   ===================================================================== */
HAL_StatusTypeDef ClavierI2C_ReadRaw(uint8_t *pKey)
{
    if (s_hi2c == NULL || pKey == NULL)
    {
        return HAL_ERROR;
    }

    return HAL_I2C_Master_Receive(s_hi2c,
                                  CLAVIER_I2C_ADDR,
                                  pKey,
                                  1,
                                  20);   // timeout 20 ms
}
