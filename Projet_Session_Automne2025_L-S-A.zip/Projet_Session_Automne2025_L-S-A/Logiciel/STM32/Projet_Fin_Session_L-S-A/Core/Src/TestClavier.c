/*
 * TestClavier.c
 *
 *  Created on: Nov 26, 2025
 *      Author: 2001082
 */
#include "TestClavier.h"
#include "Lecture_I2C_Clavier.h"
#include "lcd.h"
#include <stdio.h>

/*
 * Cette fonction est appelée régulièrement par main().
 * Elle vérifie :
 *   1. Si le clavier est présent
 *   2. Si une touche est lue
 *   3. Affiche la valeur hex sur le LCD
 */
void TestClavier_Task(void)
{
    static uint32_t lastTick = 0;
    uint32_t now = HAL_GetTick();

    /* On met à jour toutes les ~150 ms */
    if ((now - lastTick) < 150)
    {
        return;
    }
    lastTick = now;

    uint8_t touche = 0;
    char buffer[16];

    /* 1) Vérifier la présence du clavier */
    if (ClavierI2C_IsReady() != HAL_OK)
    {
        LCD_SetCursor(0, 1);
        LCD_Print("Clavier absent     ");
        return;
    }

    /* 2) Lecture d'un octet */
    if (ClavierI2C_ReadRaw(&touche) == HAL_OK)
    {
        LCD_SetCursor(0, 1);
        LCD_Print("Touche: ");

        sprintf(buffer, "%02X  ", touche);
        LCD_Print(buffer);
    }
    else
    {
        LCD_SetCursor(0, 1);
        LCD_Print("Erreur lecture I2C ");
    }
}


