#include "lcd.h"

/*
 * Fonctions internes (statiques) non visibles hors de ce fichier.
 */
static void LCD_PulseEnable(void);
static void LCD_Send4bits(uint8_t data4);
static void LCD_SendByte(uint8_t data8, uint8_t rs);
static void LCD_Command(uint8_t cmd);
static void LCD_Data(uint8_t data);


/* ==========================================================
   LCD_Init
   ----------------------------------------------------------
   - Met le LCD en mode 4 bits
   - Configure le nombre de lignes, police, etc.
   - Allume l'affichage
   - Met l'entrée en auto-incrément
   ========================================================== */
void LCD_Init(void)
{
    // Attente après power-up (>15ms). On met large pour être safe.
    HAL_Delay(2);

    // S'assurer que RS=0, RW=0, EN=0 au départ
    HAL_GPIO_WritePin(LCD_RS_GPIO_Port, LCD_RS_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_RW_GPIO_Port, LCD_RW_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_EN_GPIO_Port, LCD_EN_Pin, GPIO_PIN_RESET);

    /*
     * Séquence d'init standard HD44780 pour passer en 4 bits :
     * envoyer 0x3 (nibble 0b0011) trois fois
     * puis envoyer 0x2 (0b0010) pour dire "je suis en 4 bits"
     */
    LCD_Send4bits(0x03);
    HAL_Delay(5);

    LCD_Send4bits(0x03);
    HAL_Delay(5);

    LCD_Send4bits(0x03);
    HAL_Delay(5);

    // Passe en 4-bit
    LCD_Send4bits(0x02);
    HAL_Delay(5);

    // Function set: 4-bit, 2 lines, 5x8 dots
    // 0x28 = 0b0010 1000
    LCD_Command(0x28);

    // Display OFF
    LCD_Command(0x08);

    // Clear
    LCD_Command(0x01);
    HAL_Delay(2);

    // Entry mode set: cursor moves right, no display shift
    LCD_Command(0x06);

    // Display ON, cursor OFF, blink OFF
    LCD_Command(0x0C);
}


/* ==========================================================
   LCD_Clear
   ----------------------------------------------------------
   Efface complètement l'écran et remet le curseur (0,0).
   (Commande 0x01 sur HD44780)
   ========================================================== */
void LCD_Clear(void)
{
    LCD_Command(0x01); // Clear display
    HAL_Delay(2);      // Cette commande est lente
}


/* ==========================================================
   LCD_SetCursor
   ----------------------------------------------------------
   Place le curseur à la colonne "col" et la ligne "row".

   Sur un LCD 20x4 le mapping mémoire (DDRAM) est:
   row 0 -> base 0x00
   row 1 -> base 0x40
   row 2 -> base 0x14
   row 3 -> base 0x54

   On envoie ensuite la commande "Set DDRAM Address":
   0x80 | adresse
   ========================================================== */
void LCD_SetCursor(uint8_t col, uint8_t row)
{
    static const uint8_t row_addr[4] = {0x00, 0x40, 0x14, 0x54};

    if (row > 3)
        row = 3; // sécurité

    uint8_t addr = row_addr[row] + col;
    LCD_Command(0x80 | addr);
}


/* ==========================================================
   LCD_Print
   ----------------------------------------------------------
   Affiche une chaîne ASCII (classique, terminée par '\0')
   depuis la position actuelle du curseur.
   ========================================================== */
void LCD_Print(const char *s)
{
    while (*s)
    {
        LCD_Data((uint8_t)*s++);
    }
}


/* ==========================================================
   LCD_PutChar
   ----------------------------------------------------------
   Affiche UN caractère (par ex. 'A', '6', ou un caractère
   personnalisé 0..7 venant de la CGRAM).
   ========================================================== */
void LCD_PutChar(uint8_t c)
{
    LCD_Data(c);
}


/* ==========================================================
   LCD_CreateChar
   ----------------------------------------------------------
   Crée un caractère personnalisé dans la CGRAM.

   num     : 0..7 -> index du caractère
   pattern : tableau de 8 lignes, 5 bits utiles par ligne

   Après création, tu peux l'afficher avec LCD_PutChar(num).
   ========================================================== */
void LCD_CreateChar(uint8_t num, uint8_t *pattern)
{
    if (num > 7) return; // HD44780 = max 8 customs

    // Adresse de base CGRAM = 0x40
    // Chaque caractère prend 8 octets.
    LCD_Command(0x40 + (num << 3));

    for (uint8_t i = 0; i < 8; i++)
    {
        LCD_Data(pattern[i]);
    }

    // Revenir à la DDRAM (affichage normal) en replaçant le curseur.
    LCD_Command(0x80);
}


/* ==========================================================
   Fonctions internes bas niveau
   ========================================================== */

/*
 * LCD_PulseEnable
 * ---------------
 * Génère un pulse sur EN (PB11) pour dire au LCD :
 * "Lis les bits D4..D7 maintenant".
 */
static void LCD_PulseEnable(void)
{
    HAL_GPIO_WritePin(LCD_EN_GPIO_Port, LCD_EN_Pin, GPIO_PIN_SET);
    for (volatile int i = 0; i < 100; i++) { __NOP(); }
    HAL_GPIO_WritePin(LCD_EN_GPIO_Port, LCD_EN_Pin, GPIO_PIN_RESET);
    for (volatile int i = 0; i < 100; i++) { __NOP(); }
}


/*
 * LCD_Send4bits
 * -------------
 * Pose un nibble (4 bits) sur D4..D7 et envoie le pulse EN.
 * data4 : bits 3..0 correspondent à D7..D4 ?
 *
 * Attention : nous envoyons les bits comme suit :
 *   bit0 -> D4
 *   bit1 -> D5
 *   bit2 -> D6
 *   bit3 -> D7
 */
static void LCD_Send4bits(uint8_t data4)
{
    HAL_GPIO_WritePin(LCD_D4_GPIO_Port, LCD_D4_Pin,
                      (data4 & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(LCD_D5_GPIO_Port, LCD_D5_Pin,
                      (data4 & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(LCD_D6_GPIO_Port, LCD_D6_Pin,
                      (data4 & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(LCD_D7_GPIO_Port, LCD_D7_Pin,
                      (data4 & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    LCD_PulseEnable();
}


/*
 * LCD_SendByte
 * ------------
 * Envoie un octet complet vers le LCD :
 * - D'abord le nibble haut (bits 7..4)
 * - Puis le nibble bas (bits 3..0)
 *
 * rs = 0 => c'est une commande
 * rs = 1 => c'est une donnée (caractère)
 *
 * On force RW = 0 (écriture uniquement).
 */
static void LCD_SendByte(uint8_t data8, uint8_t rs)
{
    // RS : 0 = commande, 1 = data
    HAL_GPIO_WritePin(LCD_RS_GPIO_Port, LCD_RS_Pin,
                      rs ? GPIO_PIN_SET : GPIO_PIN_RESET);

    // RW = 0 -> écriture
    HAL_GPIO_WritePin(LCD_RW_GPIO_Port, LCD_RW_Pin, GPIO_PIN_RESET);

    // High nibble
    LCD_Send4bits(data8 >> 4);

    // Low nibble
    LCD_Send4bits(data8 & 0x0F);

    // tempo de sécurité, car on ne lit pas le busy flag
    HAL_Delay(1);
}


/*
 * LCD_Command
 * -----------
 * Envoie une commande au LCD (clear, set cursor, etc.)
 */
static void LCD_Command(uint8_t cmd)
{
    LCD_SendByte(cmd, 0);
}


/*
 * LCD_Data
 * --------
 * Envoie une donnée (un caractère à afficher)
 */
static void LCD_Data(uint8_t data)
{
    LCD_SendByte(data, 1);
}
