/*
 * system_init.h
 *
 *  Created on: Nov 26, 2025
 *      Author: 2001082
 */

#ifndef INC_SYSTEM_INIT_H_
#define INC_SYSTEM_INIT_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"

/*
 * Initialise tout le système :
 * - HAL + clock
 * - GPIO (LCD + I2C1)
 * - I2C1
 * - LCD
 * - Module Clavier I2C
 */
void System_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* INC_SYSTEM_INIT_H_ */
