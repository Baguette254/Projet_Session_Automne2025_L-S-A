#ifndef LECTURE_I2C_CLAVIER_H
#define LECTURE_I2C_CLAVIER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"
#include <stdint.h>

/* Adresse du clavier I2C (format HAL = adresse 8 bits) */
#define CLAVIER_I2C_ADDR   (0x28 << 1)

/**
 * Initialise le module clavier : on fournit l’interface I2C utilisée.
 */
void ClavierI2C_Init(I2C_HandleTypeDef *hi2c);

/**
 * Vérifie si le clavier répond sur le bus (ping I2C).
 * Retourne HAL_OK si l’esclave répond.
 */
HAL_StatusTypeDef ClavierI2C_IsReady(void);

/**
 * Lit 1 octet du clavier.
 * Retourne HAL_OK si réussi, et place la touche dans *pKey.
 */
HAL_StatusTypeDef ClavierI2C_ReadRaw(uint8_t *pKey);

#ifdef __cplusplus
}
#endif

#endif /* LECTURE_I2C_CLAVIER_H */
