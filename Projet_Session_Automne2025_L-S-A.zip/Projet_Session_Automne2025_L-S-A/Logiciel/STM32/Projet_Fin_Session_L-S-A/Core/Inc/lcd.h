#ifndef LCD_H
#define LCD_H

#include "stm32f1xx_hal.h"
#include <stdint.h>

/*
 * Mapping des broches LCD <-> STM32
 * Adapter ici si jamais tu changes le câblage.
 */

#define LCD_RS_GPIO_Port GPIOB
#define LCD_RS_Pin       GPIO_PIN_9

#define LCD_RW_GPIO_Port GPIOB
#define LCD_RW_Pin       GPIO_PIN_10

#define LCD_EN_GPIO_Port GPIOB
#define LCD_EN_Pin       GPIO_PIN_11

#define LCD_D4_GPIO_Port GPIOB
#define LCD_D4_Pin       GPIO_PIN_12

#define LCD_D5_GPIO_Port GPIOB
#define LCD_D5_Pin       GPIO_PIN_13

#define LCD_D6_GPIO_Port GPIOB
#define LCD_D6_Pin       GPIO_PIN_14

#define LCD_D7_GPIO_Port GPIOB
#define LCD_D7_Pin       GPIO_PIN_15


/* ========== Fonctions publiques (API LCD) ========== */

/* Initialise le LCD (mode 4 bits, efface l'écran, allume l'affichage) */
void LCD_Init(void);

/* Efface l'écran et remet le curseur en haut à gauche */
void LCD_Clear(void);

/* Définit la position du curseur
 * col: 0..19
 * row: 0..3 (20x4)
 */
void LCD_SetCursor(uint8_t col, uint8_t row);

/* Affiche une chaîne ASCII (terminée par 0) à partir de la position courante */
void LCD_Print(const char *s);

/* Envoie un seul caractère déjà prêt (ex: un caractère custom, ou 'A') */
void LCD_PutChar(uint8_t c);

/* Crée un caractère personnalisé
 * num: 0..7 (slot CGRAM)
 * pattern: tableau[8] contenant les 8 lignes de 5 pixels
 */
void LCD_CreateChar(uint8_t num, uint8_t *pattern);

#endif // LCD_H
