#include "UART.h"
#include "main.h"

uint8_t UART_RxByte = 0;
uint8_t UART_LastBytes[8];
uint8_t idx = 0;
uint8_t UART_NewFrame = 0;

void UART_Init_IT(UART_HandleTypeDef *huart)
{
    HAL_UART_Receive_IT(huart, &UART_RxByte, 1);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    UART_LastBytes[idx++] = UART_RxByte;

    if (idx >= 8)
    {
        idx = 0;
        UART_NewFrame = 1;
    }

    HAL_UART_Receive_IT(huart, &UART_RxByte, 1);
}
