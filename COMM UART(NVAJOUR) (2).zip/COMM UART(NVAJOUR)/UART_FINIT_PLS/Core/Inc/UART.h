#ifndef __UART_H
#define __UART_H

#include "stm32f1xx_hal.h"

extern uint8_t UART_RxByte;
extern uint8_t UART_LastBytes[8];
extern uint8_t UART_NewFrame;

void UART_Init_IT(UART_HandleTypeDef *huart);

#endif
