#ifndef LCD_H
#define LCD_H

#include "stm32f1xx_hal.h"
#include <stdint.h>

/*
 * Mapping __des__ __broches__ LCD <-> STM32
 * Adapter __ici__ __si__ __jamais__ __tu__ changes __le__ __câblage__.
 */

#define LCD_RS_GPIO_Port GPIOB
#define LCD_RS_Pin       GPIO_PIN_9

#define LCD_RW_GPIO_Port GPIOB
#define LCD_RW_Pin       GPIO_PIN_10

#define LCD_EN_GPIO_Port GPIOB
#define LCD_EN_Pin       GPIO_PIN_11

#define LCD_D4_GPIO_Port GPIOB
#define LCD_D4_Pin       GPIO_PIN_12

#define LCD_D5_GPIO_Port GPIOB
#define LCD_D5_Pin       GPIO_PIN_13

#define LCD_D6_GPIO_Port GPIOB
#define LCD_D6_Pin       GPIO_PIN_14

#define LCD_D7_GPIO_Port GPIOB
#define LCD_D7_Pin       GPIO_PIN_15

/* ========== __Fonctions__ __publiques__ (API LCD) ========== */

/* __Initialise__ __le__ LCD (mode 4 bits, __efface__ l'écran, __allume__ l'affichage) */
void LCD_Init(void);

/* __Efface__ l'écran __et__ __remet__ __le__ __curseur__ __en__ __haut__ à __gauche__ */
void LCD_Clear(void);

/* __Définit__ __la__ position __du__ __curseur__
 * __col__: 0..19
 * row: 0..3 (20x4)
 */
void LCD_SetCursor(uint8_t col, uint8_t row);

/* __Affiche__ __une__ __chaîne__ ASCII (__terminée__ par 0) à __partir__ __de__ __la__ position __courante__ */
void LCD_Print(const char *s);

/* __Envoie__ __un__ __seul__ __caractère__ __déjà__ __prêt__ (__ex__: __un__ __caractère__ custom, __ou__ 'A') */
void LCD_PutChar(uint8_t c);

/* __Crée__ __un__ __caractère__ __personnalisé__
 * __num__: 0..7 (slot CGRAM)
 * pattern: tableau[8] __contenant__ __les__ 8 __lignes__ __de__ 5 pixels
 */
void LCD_CreateChar(uint8_t num, uint8_t *pattern);

#endif // LCD_H
